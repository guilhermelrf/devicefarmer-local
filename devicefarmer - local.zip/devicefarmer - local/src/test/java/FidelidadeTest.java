import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.remote.MobileCapabilityType;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.MalformedURLException;
import java.net.URL;

public class FidelidadeTest {
    private AppiumDriver<MobileElement> driver;

    @Before
    public void setUp() throws MalformedURLException {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        // appium
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "11");
        capabilities.setCapability(MobileCapabilityType.UDID, "emulator-5554");
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "generic_x86_arm");
        capabilities.setCapability(MobileCapabilityType.APP, "C:\\Users\\gdosreis\\base.apk");
        capabilities.setCapability("appPackage", "com.outsystemsenterprise.fidelidadep10.MyFidelidade");
        capabilities.setCapability("appActivity", ".MainActivity");

        // appium driver install uiautomator2
        capabilities.setCapability("automationName", "UiAutomator2");

        URL url = new URL("http://127.0.0.1:4723/");
        driver = new AppiumDriver<MobileElement>(url, capabilities);
    }

    @Test
    public void openFidelidadeApp() {
        try {
            Thread.sleep(20000); // Sleep for 20 seconds
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        // Locate the username, password fields, and login button using their IDs or other attributes
        MobileElement usernameField = driver.findElement(By.xpath("//android.widget.EditText[@resource-id=\"username\"]"));
        MobileElement passwordField = driver.findElement(By.xpath("//android.widget.EditText[@resource-id=\"password\"]"));
        MobileElement loginButton = driver.findElement(By.xpath("//android.view.View[@content-desc=\"ENTRAR\"]"));

        // Enter username and password
        usernameField.sendKeys("256173508");
        passwordField.sendKeys("123456789");

        // Click the login button
        loginButton.click();

        // You may need to add some validation/assertions here based on the behavior after login
        
    }

    @After
    public void tearDown() {
        try {
            Thread.sleep(5000); // Sleep for 5 seconds
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        if (driver != null) {
            driver.quit();
        }
    }
}
